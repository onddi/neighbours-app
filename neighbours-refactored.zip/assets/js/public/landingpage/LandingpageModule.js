angular.module('LandingpageModule', ['toastr', 'compareTo','LandingpageControllers']);
