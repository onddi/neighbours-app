angular.module('SignupModule', ['toastr','compareTo','backend.services','angucomplete-alt', 'SignupControllers']);
