/**
 * HousingController
 *
 * @description :: Server-side logic for managing Housings
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

